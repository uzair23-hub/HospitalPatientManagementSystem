using System.ComponentModel.DataAnnotations;

namespace HospitalPMS.Models
{
    public class Patient
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]
        [Display(Name = "Patient Name")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Age is required")]
        [Range(0, 150, ErrorMessage = "Age must be between 0 and 150")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Disease is required")]
        [StringLength(200, ErrorMessage = "Disease cannot exceed 200 characters")]
        public string Disease { get; set; } = string.Empty;

        [Required(ErrorMessage = "Doctor name is required")]
        [StringLength(100, ErrorMessage = "Doctor name cannot exceed 100 characters")]
        [Display(Name = "Assigned Doctor")]
        public string Doctor { get; set; } = string.Empty;

        [Display(Name = "Admission Date")]
        [DataType(DataType.Date)]
        public DateTime AdmissionDate { get; set; } = DateTime.Now;
    }
}
