using Microsoft.AspNetCore.Mvc;
using HospitalPMS.Data;

namespace HospitalPMS.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            ViewBag.TotalPatients = _context.Patients.Count();
            ViewBag.TotalDoctors = _context.Patients.Select(p => p.Doctor).Distinct().Count();
            ViewBag.TotalDiseases = _context.Patients.Select(p => p.Disease).Distinct().Count();
            return View();
        }
    }
}
