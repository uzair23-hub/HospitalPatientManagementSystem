using Microsoft.EntityFrameworkCore;
using HospitalPMS.Models;

namespace HospitalPMS.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Patient> Patients { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed sample data
            modelBuilder.Entity<Patient>().HasData(
                new Patient { Id = 1, Name = "Ahmed Khan", Age = 35, Disease = "Diabetes", Doctor = "Dr. Ali Hassan", AdmissionDate = DateTime.Now.AddDays(-10) },
                new Patient { Id = 2, Name = "Fatima Malik", Age = 28, Disease = "Hypertension", Doctor = "Dr. Sara Ahmed", AdmissionDate = DateTime.Now.AddDays(-5) },
                new Patient { Id = 3, Name = "Usman Raza", Age = 45, Disease = "Diabetes", Doctor = "Dr. Ali Hassan", AdmissionDate = DateTime.Now.AddDays(-3) },
                new Patient { Id = 4, Name = "Ayesha Siddiqui", Age = 52, Disease = "Asthma", Doctor = "Dr. Sara Ahmed", AdmissionDate = DateTime.Now.AddDays(-7) },
                new Patient { Id = 5, Name = "Bilal Qureshi", Age = 31, Disease = "Fever", Doctor = "Dr. Kamran Shah", AdmissionDate = DateTime.Now.AddDays(-1) }
            );
        }
    }
}
